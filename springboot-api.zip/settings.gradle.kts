
pluginManagement {
    repositories {
        mavenCentral()
    }
}

rootProject.name = "springboot-api"

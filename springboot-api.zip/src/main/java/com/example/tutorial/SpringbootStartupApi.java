
package com.example.tutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootStartupApi {
    public static void main(String[] args) {
        SpringApplication.run(SpringbootStartupApi.class, args);
    }
}

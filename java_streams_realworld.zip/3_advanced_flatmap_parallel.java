import java.util.*;
import java.util.stream.Collectors;

class Campaign {
    String campaignId;
    List<String> offerIds;

    Campaign(String campaignId, List<String> offerIds) {
        this.campaignId = campaignId;
        this.offerIds = offerIds;
    }
}

class Transaction {
    String customerId;
    double amount;
    long timestamp;

    Transaction(String customerId, double amount, long timestamp) {
        this.customerId = customerId;
        this.amount = amount;
        this.timestamp = timestamp;
    }
}

public class AdvancedStreams {
    public static void main(String[] args) {
        List<Campaign> campaigns = Arrays.asList(
            new Campaign("camp1", Arrays.asList("offer1", "offer2")),
            new Campaign("camp2", Arrays.asList("offer3"))
        );

        List<String> allOfferIds = campaigns.stream()
            .flatMap(c -> c.offerIds.stream())
            .collect(Collectors.toList());

        System.out.println("Offers from campaigns: " + allOfferIds);

        List<Transaction> transactions = new ArrayList<>();
        for (int i = 0; i < 10000; i++) {
            transactions.add(new Transaction("cust" + (i % 100), Math.random() * 500, System.currentTimeMillis()));
        }

        Map<String, Double> scoreMap = transactions.parallelStream()
            .collect(Collectors.groupingBy(
                t -> t.customerId,
                Collectors.summingDouble(t -> t.amount)
            ));

        scoreMap.entrySet().stream()
            .filter(e -> e.getValue() > 1000)
            .limit(5)
            .forEach(e -> System.out.println("Suspicious: " + e.getKey() + " spent $" + e.getValue()));
    }
}
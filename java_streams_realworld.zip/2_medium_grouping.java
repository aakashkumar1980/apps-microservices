import java.util.*;
import java.util.stream.Collectors;

class Redemption {
    String offerId;
    String merchantId;
    String customerId;

    Redemption(String offerId, String merchantId, String customerId) {
        this.offerId = offerId;
        this.merchantId = merchantId;
        this.customerId = customerId;
    }
}

public class MediumGrouping {
    public static void main(String[] args) {
        List<Redemption> redemptions = Arrays.asList(
            new Redemption("offer1", "m1", "c1"),
            new Redemption("offer2", "m2", "c2"),
            new Redemption("offer3", "m1", "c3"),
            new Redemption("offer4", "m3", "c1"),
            new Redemption("offer5", "m2", "c4")
        );

        Map<String, Long> merchantRedemptionCounts = redemptions.stream()
            .collect(Collectors.groupingBy(
                r -> r.merchantId,
                Collectors.counting()
            ));

        merchantRedemptionCounts.forEach((merchant, count) ->
            System.out.println("Merchant: " + merchant + ", Redemptions: " + count));
    }
}
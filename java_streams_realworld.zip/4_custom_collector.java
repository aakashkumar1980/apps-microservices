import java.util.*;
import java.util.stream.Collector;

class Redemption {
    String customerId;
    double amount;

    Redemption(String customerId, double amount) {
        this.customerId = customerId;
        this.amount = amount;
    }
}

class RedemptionStats {
    long count = 0;
    double total = 0;
    double min = Double.MAX_VALUE;
    double max = Double.MIN_VALUE;

    void accept(Redemption r) {
        count++;
        total += r.amount;
        min = Math.min(min, r.amount);
        max = Math.max(max, r.amount);
    }

    RedemptionStats combine(RedemptionStats other) {
        this.count += other.count;
        this.total += other.total;
        this.min = Math.min(this.min, other.min);
        this.max = Math.max(this.max, other.max);
        return this;
    }

    double getAverage() {
        return count == 0 ? 0 : total / count;
    }

    @Override
    public String toString() {
        return String.format("Count: %d, Total: %.2f, Min: %.2f, Max: %.2f, Avg: %.2f",
                count, total, min, max, getAverage());
    }
}

public class CustomCollectorExample {
    public static void main(String[] args) {
        List<Redemption> redemptions = Arrays.asList(
            new Redemption("c1", 100),
            new Redemption("c2", 250),
            new Redemption("c3", 75),
            new Redemption("c4", 120)
        );

        Collector<Redemption, RedemptionStats, RedemptionStats> collector = Collector.of(
            RedemptionStats::new,
            RedemptionStats::accept,
            RedemptionStats::combine
        );

        RedemptionStats stats = redemptions.stream().collect(collector);
        System.out.println(stats);
    }
}
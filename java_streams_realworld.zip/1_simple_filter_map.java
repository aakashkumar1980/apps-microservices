import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

class Offer {
    String offerId;
    boolean isActive;
    LocalDate expiry;

    public Offer(String offerId, boolean isActive, LocalDate expiry) {
        this.offerId = offerId;
        this.isActive = isActive;
        this.expiry = expiry;
    }
}

public class SimpleFilterMap {
    public static void main(String[] args) {
        List<Offer> offers = Arrays.asList(
            new Offer("offer1", true, LocalDate.now().plusDays(5)),
            new Offer("offer2", false, LocalDate.now().plusDays(3)),
            new Offer("offer3", true, LocalDate.now().minusDays(1))
        );

        List<Offer> validOffers = offers.stream()
            .filter(o -> o.isActive)
            .filter(o -> o.expiry.isAfter(LocalDate.now()))
            .collect(Collectors.toList());

        validOffers.forEach(o -> System.out.println("Valid Offer: " + o.offerId));
    }
}
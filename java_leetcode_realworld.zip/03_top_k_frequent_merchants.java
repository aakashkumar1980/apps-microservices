// LeetCode 347 - Top K Frequent Elements
// Real-world: Return top K merchants by number of redemptions

import java.util.*;

public class TopKFrequentMerchants {
    public static void main(String[] args) {
        String[] redemptions = {"m1", "m2", "m1", "m3", "m2", "m1", "m3", "m2", "m2"};
        int k = 2;

        Map<String, Integer> freq = new HashMap<>();
        for (String m : redemptions) {
            freq.put(m, freq.getOrDefault(m, 0) + 1);
        }

        PriorityQueue<Map.Entry<String, Integer>> heap = new PriorityQueue<>(
            Map.Entry.comparingByValue()
        );

        for (Map.Entry<String, Integer> entry : freq.entrySet()) {
            heap.offer(entry);
            if (heap.size() > k) heap.poll();
        }

        while (!heap.isEmpty()) {
            Map.Entry<String, Integer> entry = heap.poll();
            System.out.println("Merchant: " + entry.getKey() + ", Redemptions: " + entry.getValue());
        }
    }
}
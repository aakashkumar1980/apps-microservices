// LeetCode 1 - Two Sum
// Real-world: Alert if two recent transactions together exceed a fraud threshold

import java.util.*;

public class TwoSumTransactionAlert {
    public static void main(String[] args) {
        int[] txns = {100, 180, 40, 60, 150};
        int threshold = 200;

        Map<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < txns.length; i++) {
            int complement = threshold - txns[i];
            if (map.containsKey(complement)) {
                System.out.println("Alert: Transaction pair found: " + txns[i] + " + " + complement);
                return;
            }
            map.put(txns[i], i);
        }
        System.out.println("No suspicious pair found.");
    }
}
// LeetCode 3 - Longest Substring Without Repeating Characters
// Real-world: Impression service avoids logging duplicate views within a sliding window

import java.util.*;

public class SlidingWindowDedup {
    public static void main(String[] args) {
        String[] views = {"offer1", "offer2", "offer1", "offer3", "offer2"};
        Set<String> window = new HashSet<>();
        int maxWindow = 0, left = 0;

        for (int right = 0; right < views.length; right++) {
            while (window.contains(views[right])) {
                window.remove(views[left++]);
            }
            window.add(views[right]);
            maxWindow = Math.max(maxWindow, right - left + 1);
        }

        System.out.println("Max unique views in sequence: " + maxWindow);
    }
}
import java.util.*;
import java.util.stream.*;

public class ParallelBatchScoring {
    // Simulates ML model scoring function
    static double runScoringModel(String customerId) {
        try { Thread.sleep(10); } catch (InterruptedException ignored) {}
        return Math.random() * 100;
    }

    public static void main(String[] args) {
        List<String> customers = IntStream.range(0, 1000)
            .mapToObj(i -> "cust" + i)
            .collect(Collectors.toList());

        // Run model scoring in parallel using parallelStream
        List<Double> scores = customers.parallelStream()
            .map(ParallelBatchScoring::runScoringModel)
            .collect(Collectors.toList());

        System.out.println("Scored " + scores.size() + " customers.");
    }
}
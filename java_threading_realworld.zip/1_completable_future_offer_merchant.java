import java.util.concurrent.*;

class Offer {}
class Merchant {}
class EnrichedOffer {
    Offer offer;
    Merchant merchant;

    EnrichedOffer(Offer offer, Merchant merchant) {
        this.offer = offer;
        this.merchant = merchant;
    }
}

public class OfferMerchantAsync {
    // Simulates service call to fetch offer
    static Offer fetchOffer(String offerId) {
        sleep(100);
        return new Offer();
    }

    // Simulates service call to fetch merchant
    static Merchant fetchMerchant(String merchantId) {
        sleep(150);
        return new Merchant();
    }

    // Fallback in case of exception
    static EnrichedOffer fallbackOffer() {
        return new EnrichedOffer(null, null);
    }

    static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    public static void main(String[] args) {
        // Async fetch offer and merchant, then combine both
        CompletableFuture<Offer> offerFuture = CompletableFuture.supplyAsync(() -> fetchOffer("O123"));
        CompletableFuture<Merchant> merchantFuture = CompletableFuture.supplyAsync(() -> fetchMerchant("M456"));

        CompletableFuture<EnrichedOffer> enriched = offerFuture
            .thenCombine(merchantFuture, (offer, merchant) -> new EnrichedOffer(offer, merchant))
            .exceptionally(e -> fallbackOffer());

        enriched.thenAccept(eo -> System.out.println("Enriched offer generated."));
    }
}
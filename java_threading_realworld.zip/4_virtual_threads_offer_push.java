import java.util.concurrent.*;
import java.util.*;

public class VirtualThreadPush {
    static void pushToRedis(String offerId) {
        try {
            Thread.sleep(50); // Simulate network IO
            System.out.println("Pushed " + offerId);
        } catch (InterruptedException ignored) {}
    }

    public static void main(String[] args) throws InterruptedException {
        List<String> offerIds = List.of("O1", "O2", "O3", "O4", "O5");

        // Use virtual threads to perform high-concurrency tasks (Java 21+)
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            List<Callable<Void>> tasks = offerIds.stream()
                .map(id -> (Callable<Void>) () -> { pushToRedis(id); return null; })
                .toList();

            executor.invokeAll(tasks);
        }
    }
}
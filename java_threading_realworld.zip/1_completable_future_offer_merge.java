import java.util.concurrent.*;

class Offer {}
class Merchant {}
class EnrichedOffer {
    Offer offer;
    Merchant merchant;
    EnrichedOffer(Offer o, Merchant m) {
        this.offer = o;
        this.merchant = m;
    }
}

public class OfferMergeExample {
    static Offer fetchOffer(String offerId) {
        try { Thread.sleep(100); } catch (InterruptedException ignored) {}
        return new Offer();
    }

    static Merchant fetchMerchant(String merchantId) {
        try { Thread.sleep(120); } catch (InterruptedException ignored) {}
        return new Merchant();
    }

    static EnrichedOffer fallbackOffer() {
        return new EnrichedOffer(new Offer(), new Merchant());
    }

    public static void main(String[] args) throws Exception {
        String offerId = "offer123";
        String merchantId = "merchant456";

        CompletableFuture<Offer> offerFuture = CompletableFuture.supplyAsync(() -> fetchOffer(offerId));
        CompletableFuture<Merchant> merchantFuture = CompletableFuture.supplyAsync(() -> fetchMerchant(merchantId));

        CompletableFuture<EnrichedOffer> enrichedFuture = offerFuture
            .thenCombine(merchantFuture, EnrichedOffer::new)
            .exceptionally(ex -> fallbackOffer());

        EnrichedOffer result = enrichedFuture.get();
        System.out.println("✅ Offer merged successfully!");
    }
}
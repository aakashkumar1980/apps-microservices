import java.util.*;
import java.util.stream.Collectors;

public class MLParallelScoring {
    static double runScoringModel(String txnId) {
        try { Thread.sleep(10); } catch (InterruptedException ignored) {}
        return Math.random() * 100;
    }

    public static void main(String[] args) {
        List<String> txnIds = new ArrayList<>();
        for (int i = 1; i <= 1000; i++) {
            txnIds.add("txn" + i);
        }

        List<Double> scores = txnIds.parallelStream()
            .map(MLParallelScoring::runScoringModel)
            .collect(Collectors.toList());

        System.out.println("✅ Completed scoring " + scores.size() + " transactions");
    }
}
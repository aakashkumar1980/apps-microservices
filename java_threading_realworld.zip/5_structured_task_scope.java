import java.util.concurrent.*;

class OfferData {}
class LoyaltyData {}
class Personalization {}
class FinalOfferBundle {
    FinalOfferBundle(OfferData o, LoyaltyData l, Personalization p) {}
}

public class StructuredScopeExample {
    static OfferData offerService() throws InterruptedException {
        Thread.sleep(100); return new OfferData();
    }
    static LoyaltyData loyaltyService() throws InterruptedException {
        Thread.sleep(150); return new LoyaltyData();
    }
    static Personalization personalize() throws InterruptedException {
        Thread.sleep(80); return new Personalization();
    }

    public static void main(String[] args) throws Exception {
        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
            Future<OfferData> offerF = scope.fork(() -> offerService());
            Future<LoyaltyData> loyaltyF = scope.fork(() -> loyaltyService());
            Future<Personalization> persF = scope.fork(() -> personalize());

            scope.join();
            scope.throwIfFailed();

            FinalOfferBundle result = new FinalOfferBundle(
                offerF.result(), loyaltyF.result(), persF.result());

            System.out.println("✅ Final offer bundle ready");
        }
    }
}
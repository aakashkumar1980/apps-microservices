import java.util.concurrent.*;

class OfferData {}
class LoyaltyData {}
class Personalization {}
class FinalBundle {
    FinalBundle(OfferData o, LoyaltyData l, Personalization p) {}
}

public class StructuredScopeDemo {
    static OfferData offerService() { return new OfferData(); }
    static LoyaltyData loyaltyService() { return new LoyaltyData(); }
    static Personalization personalize() { return new Personalization(); }

    public static void main(String[] args) throws Exception {
        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
            // Fork all async tasks
            Future<OfferData> offerF = scope.fork(StructuredScopeDemo::offerService);
            Future<LoyaltyData> loyaltyF = scope.fork(StructuredScopeDemo::loyaltyService);
            Future<Personalization> persF = scope.fork(StructuredScopeDemo::personalize);

            scope.join();              // Wait for all tasks
            scope.throwIfFailed();     // Fail fast if any failed

            FinalBundle bundle = new FinalBundle(
                offerF.result(), loyaltyF.result(), persF.result()
            );
            System.out.println("Final bundle ready.");
        }
    }
}
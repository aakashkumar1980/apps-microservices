import java.util.*;
import java.util.concurrent.*;

public class RedisIngestionVirtualThreads {
    static void pushToRedis(String offer) {
        try { Thread.sleep(50); } catch (InterruptedException ignored) {}
        System.out.println("Pushed: " + offer);
    }

    public static void main(String[] args) throws Exception {
        List<String> offers = List.of("offer1", "offer2", "offer3", "offer4");

        try (ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {
            List<Callable<Void>> tasks = offers.stream()
                .map(offer -> (Callable<Void>) () -> {
                    pushToRedis(offer);
                    return null;
                })
                .toList();

            executor.invokeAll(tasks);
        }

        System.out.println("✅ All offers pushed using virtual threads");
    }
}
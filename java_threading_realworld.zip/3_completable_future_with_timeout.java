import java.util.concurrent.*;

class FraudResult {
    static final FraudResult SKIP = new FraudResult();
}

public class FraudWithTimeout {
    // Simulated fraud service with random delay
    static FraudResult runFraudCheck() {
        try { Thread.sleep(300); } catch (InterruptedException ignored) {}
        return new FraudResult();
    }

    public static void main(String[] args) {
        // Run fraud check with timeout and fallback
        CompletableFuture<FraudResult> fraudCheck = CompletableFuture
            .supplyAsync(FraudWithTimeout::runFraudCheck)
            .orTimeout(200, TimeUnit.MILLISECONDS)
            .exceptionally(e -> FraudResult.SKIP);

        fraudCheck.thenAccept(f -> System.out.println("Fraud check completed."));
    }
}